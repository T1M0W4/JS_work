//1
// let $name = prompt('Введите имя: ');
// console.log($name);
// alert($name);

//2
// let _year = +prompt('Введите год:'); {
//     _year -= 2024;
//     alert(_year);
// }

//3
// let _year = +prompt('Введите длину стороны квадрата:'); {
//     _year -= 2024;
//     alert(`Площаль квадрата: ${_year}`);
// }

//4
// var radius = parseFloat(prompt("Введите радиус окружности:"));

// if (isNaN(radius)) {
//     alert("Вы ввели некорректное значение!");
// } else {
//     var area = 3.14 * radius * radius;
//     alert(`Площадь окружности с радиусом ${radius} равна ${area.toFixed(2)})`);
// }

//5
// let d = +prompt('Введите растояние между городами: ');
// let t = +prompt('Введите время за которое Вы хотите добраться: ');{
// let v = d/t
// alert(`Нужная скорость ${v.toFixed(2)} для достижении из точки А в точку Б при растояниии "${d}" за это время "${t}"!`)
// }

//6
// const euro = 0.92
// let usd = +prompt("Введите сумму в доларах: ")
// let result = usd * euro
// alert(`${result}`)

//7
// let user_gb = +prompt('Введите объем флешки в Гб:')
// const mb = 820
// let gb = user_gb * 1024
// let result = Math.floor(gb/mb)
// alert(`На флешку объемом ${user_gb} Гб поместится ${result} файлов размером ${mb} Мб.`)

//8
// let money = +prompt("Введите сумму денег в кошельке:")
// let choco = +prompt("Введите цену одной шоколадки:")
// let quan_choco = Math.floor(money / choco)
// let change = money - (quan_choco * choco)
// alert(`Вы можете купить ${quan_choco} шоколадок и у вас останется ${change.toFixed(2)} казахский тугриков.`)

//9
// let number =  prompt('Введите 5 цифр:')
// if (number.length === 5 && !isNaN(number)) {
//     let modifiedNumber = number.slice(-1) + number.slice(0, -1);
//     console.log("Измененное число:", modifiedNumber);
// } else {
//     console.log("Ошибка: Введите корректное пятизначное число.");
// }

//10
// let sales = parseFloat(prompt("Введите общую сумму продаж за месяц в долларах:"));


// if (!isNaN(sales) && sales >= 0) {
//     let baseSalary = 250;
//     let commission = 0.10 * sales;
//     let totalSalary = baseSalary + commission;

//     console.log("Общая зарплата работника:", totalSalary.toFixed(2), "долларов");
// } else {
//     console.log("Ошибка: Введите корректную сумму продаж.");
// }

